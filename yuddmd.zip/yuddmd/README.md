# BOT IS BACK #AIUPDATE
Dikarenakan saya sudah mendapatkan base baru dan Baileys terbaru dari situs [`NPM`](https://www.npmjs.com/package/baileys), maka bot sudah dapat berjalan dengan benar, terimakasih banyak untuk yang telah mendukung pengembangan bot ini, namun saya meminta maaf jika ada fitur yang dipangkas seperti game, tictactoe, akinator, buttons dll karena Baileys ini masih dalam pengembangan. Doakan supaya bot bisa kembali update dengan normal. Have fun dan #SalamCoding!

Bot ini sekarang memiliki fitur OpenAI Chat dan buat gambar dari AI, buat seru-seruan aja wkwkwkwk :)

Last Updated Version: GabutBot-Reborn v5.0

# BOT APAKAH INI?
Bot ini adalah bot MD (Multi-Device), sehingga bot ini dapat digunakan meskipun hp pengguna mati. Bot ini masih dalam pengembangan (baileys beta) sehingga terdapat masih banyak bug di dalamnya. Bot ini No Encrypt, sehingga pengguna dapat recode (asal jangan dijual juga) dan dapat menambah fitur tertentu dengan apikey. 

Recode by me and [`ManzSteviaOFC`](https://www.youtube.com/channel/UCHEszLndQmgMITqKtwy2DXQ))

# GabutBot-Reborn
Full Featured Bot Updated Script 🤖

## NOTE
This script is for everyone, not for sale. Jika dijual neraka menunggumu brother !

<p align="center">
	<img src="https://i.ibb.co/HNrcfzB/wallpapersden-com-ao-no-exorcist-okumura-rin-man-1996x1413.jpg" width="35%" style="margin-left: auto;margin-right: auto;display: block;">
</p>
<h1 align="center">GabutBot-Reborn</h1>

This is Script of WhatsApp multi device, working with [`@adiwajshing/baileys`](https://github.com/adiwajshing/baileys)

## UNTUK PENGGUNA WINDOWS/RDP

* Unduh & Instal Git [`Klik Disini`](https://git-scm.com/downloads)
* Unduh & Instal NodeJS [`Klik Disini`](https://nodejs.org/en/download)
* Unduh & Instal FFmpeg [`Klik Disini`](https://ffmpeg.org/download.html) (**Jangan Lupa Tambahkan FFmpeg ke variabel lingkungan PATH**)


```bash
npm install yarn --global
git clone https://github.com/YangJunMing12/GabutBot-mD
cd GabutBot-MD
yarn
npm start
```

## HOW TO CONNECT TO MONGODB WHEN RUN IN HEROKU

* Create account and database in mongodb atlas [`watch here`](https://youtu.be/rPqRyYJmx2g)
* when you already have a database, you just need to take mongourl
* Put mongourl in Procfile `web: node . --db 'mongourl'`
* Example `web: node . -- db 'Your Mongo URI'`



## FOR TERMUX/UBUNTU/SSH USER

```bash
apt update && apt upgrade
apt install git -y
apt install nodejs -y
apt install ffmpeg -y
git clone https://github.com/YangJunMing12/GabutBot-IV
cd GabutBot-MD
npm i
```

## RECOMMENDED INSTALL ON TERMUX

```bash
pkg install yarn
yarn
```

## Installing
```bash
$ node .
```

## Features

| Group |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  Hidetag               |
|       ✅        |  Grup close atau open       |
|       ✅        |  Gcname          |
|       ✅        |  Gcdesk       |
|       ✅        |  Add              |
|       ✅        |  Kick              |
|       ✅        |  Ownergc              |
|       ✅        |  Leave              |
|       ✅        |  Promote              |
|       ✅        |  Demote              |
|       ✅        |  Ephemeral             |
|       ✅        |  Vote           |
|       ✅        |  Antilink         |

| Search |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  Youtube play             |
|       ✅        |  Youtube search     |
|       ✅        |  Google & google image      |
|       ✅        |  Pinterest       |
|       ✅        |  Search Wallpaper           |
|       ✅        |  Youtube Search             |
|       ✅        |  Spotify Search           |
|       ✅        |  Wikimedia             |
|       ✅        |  Ringtone             |
|       ✅        |  Stalk People          |
|       ✅        |  Gsmarena            |
|       ✅        |  Kamus KBBI          |

| Creator |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  ATTP & TTP            |
|       ✅        |  Sticker To Image/Video/GIF   |
|       ✅        |  Emoji Mix     |
|       ✅        |  Pinterest       |
|       ✅        |  Sticker          |
|       ✅        |  Sticker WM            |
|       ✅        |  Sticker Meme         |
|       ✅        |  KTP Fake Maker         |
|       ✅        |  Sertifikat Bucin/Pacaran/Tolol        |
|       ✅        |  Translate Kode Biner         |

| Downloader |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  Tiktok WM/No WM/Slide Show            |
|       ✅        |  Spotify/Joox/SoundCloud Download |
|       ✅        |  Youtube Music     |
|       ✅        |  Youtube Video      |
|       ✅        |  Facebook/IG/Twitter Download          |
|       ✅        |  ZippyShare Download       |
|       ✅        |  Get Music or Get Video        |

| AI Chat (NEW!) |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  Chat Open AI & Open AI Turbo 3.5           |
|       ✅        |  Dall-E & Diffusion (Buat gambar dari AI) |
|       ✅        |  Speech to text    |

... and more! Menfess, fun menu ready 

## ❗ Warning
WhatsApp Bot is still in the development stage, so there are a few bugs
WhatsApp Connection (BETA, not working perfectly)

Editing Number Owner & session name in [`config.js`]
Get Apikey LolHuman on [`LolHuman`](https://api.lolhuman.xyz) harga murah kok sans 


## Thanks To
* [`@adiwajshing/baileys`](https://github.com/adiwajshing/baileys)
* [`Nurutomo`](https://github.com/Nurutomo)
* [`Mhankbarbar`](https://github.com/MhankBarBar)
* [`Faiz`](https://github.com/FaizBastomi)
* [`Shiny Sebastian`](https://github.com/YangJunMing12)

```Thanks to all who have participated in the development of this script```


License: [MIT](https://en.wikipedia.org/wiki/MIT_License)

Support Me
* ```OVO``` 08116646665

# Thank you and have fun!
